package com.example.itemservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
